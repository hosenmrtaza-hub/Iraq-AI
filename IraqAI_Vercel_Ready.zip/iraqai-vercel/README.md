# IRAQ AI - نشر على Vercel

## خطوة واحدة فقط! 🚀

### الطريقة 1: مباشرة من GitHub
1. ارفع المجلد كله على GitHub repository
2. اذهب إلى [vercel.com](https://vercel.com)
3. اضغط **"New Project"**
4. اختر الـ repository
5. اضغط **"Deploy"**
6. ✅ تم! سيعمل تلقائياً

### الطريقة 2: من ملفات ZIP
1. اذهب إلى [vercel.com](https://vercel.com)
2. اضغط **"New Project"** → **"Import"**
3. ارفع المجلد كاملاً
4. اضغط **"Deploy"**
5. ✅ تم!

---

## البنية
```
/api/generate.js  ← الباك-إند (Serverless Function)
/public/
  index.html      ← الصفحة الرئيسية
  App.jsx         ← المشروع الكامل
package.json      ← Dependencies
```

## ملاحظات
- المشروع يعمل **فوراً** بدون أي إعداد إضافي
- مفتاح fal.ai مدمج في الكود
- لا يحتاج أي تعديل أو برمجة
