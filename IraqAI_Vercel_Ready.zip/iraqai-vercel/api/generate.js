import fetch from 'node-fetch';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { prompt, size = '1024x1024', style = 'realistic' } = req.body;
  if (!prompt) return res.status(400).json({ error: 'الوصف فارغ' });

  const STYLE_MAP = {
    realistic: 'photorealistic, high quality photography, 8k',
    digital: 'digital art, vibrant colors, concept art',
    painting: 'oil painting, artistic, masterpiece',
    anime: 'anime style, manga, detailed',
    '3d': '3d render, octane render, cinematic lighting'
  };

  const SIZE_MAP = {
    '1024x1024': 'square_hd',
    '1792x1024': 'landscape_16_9',
    '1024x1792': 'portrait_16_9'
  };

  const FAL_KEY = '7103f6bf-157d-4f8f-8b38-d07c364ff7c5:f91e50b30790eb3ea7da05d693d66990';
  const fullPrompt = `${prompt}, ${STYLE_MAP[style] || ''}`;

  try {
    const response = await fetch('https://fal.run/fal-ai/flux/schnell', {
      method: 'POST',
      headers: {
        'Authorization': `Key ${FAL_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prompt: fullPrompt,
        image_size: SIZE_MAP[size] || 'square_hd',
        num_inference_steps: 4,
        num_images: 1,
        enable_safety_checker: false
      })
    });

    const data = await response.json();
    const imageUrl = data?.images?.[0]?.url;
    
    if (!imageUrl) return res.status(500).json({ error: 'لم تُرجع أي صورة' });
    
    // Fetch image and return as blob
    const imgResponse = await fetch(imageUrl);
    const buffer = await imgResponse.arrayBuffer();
    
    res.setHeader('Content-Type', 'image/jpeg');
    res.send(Buffer.from(buffer));
    
  } catch (error) {
    res.status(500).json({ error: 'فشل توليد الصورة' });
  }
}
