# 🌙 IRAQ AI

**مساعدك الذكي العربي** — An advanced AI chatbot designed specifically for Arabic-speaking users.

---

## ✨ Features

- 💬 **Elegant Chat Interface** — RTL Arabic-first design with modern light theme
- 🤖 **AI Integration** — Real-time responses using DeepSeek v3.2
- 🖼️ **Image Generation** — Create images from text using Gemini 2.5 Flash
- 📜 **Conversation History** — Save and revisit past conversations
- 🔐 **User Authentication** — Secure JWT-based login
- 🎤 **Voice Input** — Speech recognition for hands-free input

---

## 🗂 Project Structure

```
iraq-ai/
├── frontend/          # React + TypeScript + Vite
│   ├── src/
│   │   ├── components/   # UI components
│   │   ├── pages/        # Chat & Login pages
│   │   ├── lib/          # API utilities
│   │   └── App.tsx
│   ├── package.json
│   └── vite.config.ts
│
└── backend/           # FastAPI + SQLAlchemy + PostgreSQL
    ├── core/          # Database & security
    ├── data_models/   # SQLAlchemy models
    ├── dependencies/  # Auth dependencies
    ├── routers/       # API routes
    ├── services/      # AI & image services
    ├── main.py
    └── requirements.txt
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ & pnpm
- Python 3.11+
- PostgreSQL

### 1. Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your API keys and database URL

# Run the server
uvicorn main:app --reload --port 8000
```

### 2. Frontend Setup

```bash
cd frontend

# Install dependencies
pnpm install

# Configure environment
cp .env.example .env
# Edit .env if needed

# Development server
pnpm dev

# Production build
pnpm build
```

### 3. Database

```sql
CREATE DATABASE iraq_ai;
```

The tables are created automatically on first run.

---

## 🔑 API Keys

| Key | Service | Get it from |
|-----|---------|-------------|
| `DEEPSEEK_API_KEY` | Chat AI | [platform.deepseek.com](https://platform.deepseek.com) |
| `GEMINI_API_KEY` | Image Generation | [aistudio.google.com](https://aistudio.google.com) |

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/auth/register` | Register new user |
| `POST` | `/auth/token` | Login & get JWT |
| `POST` | `/chat/message` | Send a chat message |
| `GET`  | `/chat/conversations` | List conversations |
| `POST` | `/images/generate` | Generate image |
| `GET`  | `/users/me` | Get user profile |
| `GET`  | `/health` | Health check |

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Vite |
| Styling | Inline styles + Google Fonts (Tajawal) |
| Backend | FastAPI, Python 3.11 |
| Database | PostgreSQL + SQLAlchemy |
| Auth | JWT (python-jose) + bcrypt |
| Chat AI | DeepSeek v3.2 |
| Image AI | Gemini 2.5 Flash |

---

## 📄 License

MIT © 2025 IRAQ AI
