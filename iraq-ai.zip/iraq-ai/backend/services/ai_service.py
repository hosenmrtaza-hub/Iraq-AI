import os
import httpx
from dotenv import load_dotenv

load_dotenv()

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
DEEPSEEK_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")

SYSTEM_PROMPT = """أنت IRAQ AI، مساعد ذكاء اصطناعي متقدم مخصص للمستخدمين العرب.
- تجيب دائماً باللغة العربية الفصيحة الواضحة
- تأخذ بعين الاعتبار الثقافة والسياق العراقي والعربي
- تكون ودوداً ومفيداً وموضوعياً
- إذا طُلب منك الرد بلغة أخرى فافعل ذلك
- تتجنب المحتوى الضار أو المسيء"""


async def get_ai_response(messages: list[dict]) -> str:
    """
    Call DeepSeek API (OpenAI-compatible) and return assistant reply.
    """
    if not DEEPSEEK_API_KEY:
        return _fallback_response(messages[-1]["content"] if messages else "")

    payload = {
        "model": DEEPSEEK_MODEL,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}] + messages,
        "max_tokens": 2048,
        "temperature": 0.7,
    }

    async with httpx.AsyncClient(timeout=60) as client:
        response = await client.post(
            f"{DEEPSEEK_BASE_URL}/chat/completions",
            headers={
                "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]


def _fallback_response(user_message: str) -> str:
    """Simple fallback when API key is not configured."""
    return (
        f"شكراً على رسالتك! للأسف، لم يتم تكوين مفتاح API بعد. "
        f"يرجى إضافة DEEPSEEK_API_KEY في ملف .env لتفعيل المساعد الذكي.\n\n"
        f"رسالتك: {user_message}"
    )
