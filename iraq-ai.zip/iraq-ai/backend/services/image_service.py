import os
import base64
import httpx
import uuid
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY  = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL    = "gemini-2.0-flash-preview-image-generation"
UPLOADS_DIR     = Path(os.getenv("UPLOADS_DIR", "uploads/images"))

UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

STYLE_PROMPTS = {
    "فوتوغرافي":    "photorealistic, professional photography, 8k, high detail",
    "فن رقمي":      "digital art, vibrant colors, concept art, artstation",
    "رسم زيتي":     "oil painting, traditional art, fine brushwork, museum quality",
    "رسوم متحركة":  "anime style, vibrant, cel shading, animated",
}


async def generate_image_from_prompt(prompt: str, style: str) -> str:
    """
    Generate an image using Gemini 2.5 Flash and return a URL.
    Falls back to a placeholder if API key is not set.
    """
    if not GEMINI_API_KEY:
        return _placeholder_url(prompt)

    style_suffix = STYLE_PROMPTS.get(style, "")
    full_prompt  = f"{prompt}, {style_suffix}" if style_suffix else prompt

    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"
    )
    payload = {
        "contents": [{"parts": [{"text": full_prompt}]}],
        "generationConfig": {"responseModalities": ["IMAGE", "TEXT"]},
    }

    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(url, json=payload)
        response.raise_for_status()
        data = response.json()

    # Extract base64 image from response
    for part in data.get("candidates", [{}])[0].get("content", {}).get("parts", []):
        if "inlineData" in part:
            image_data   = base64.b64decode(part["inlineData"]["data"])
            mime_type    = part["inlineData"]["mimeType"]
            ext          = mime_type.split("/")[-1]
            filename     = f"{uuid.uuid4().hex}.{ext}"
            file_path    = UPLOADS_DIR / filename
            file_path.write_bytes(image_data)
            return f"/uploads/images/{filename}"

    return _placeholder_url(prompt)


def _placeholder_url(prompt: str) -> str:
    """Return a placeholder image URL for development."""
    encoded = prompt[:30].replace(" ", "+")
    return f"https://placehold.co/800x450/e0e7ff/6366f1?text={encoded}"
