from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel

from core.database import get_db
from data_models.models import User, GeneratedImage
from dependencies.auth import get_current_user
from services.image_service import generate_image_from_prompt

router = APIRouter()


class ImageRequest(BaseModel):
    prompt: str
    style: str = "فوتوغرافي"


class ImageResponse(BaseModel):
    image_url: str
    prompt: str
    style: str


@router.post("/generate", response_model=ImageResponse)
async def generate_image(
    payload: ImageRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not payload.prompt.strip():
        raise HTTPException(status_code=400, detail="الوصف لا يمكن أن يكون فارغاً")

    image_url = await generate_image_from_prompt(payload.prompt, payload.style)

    record = GeneratedImage(
        user_id=current_user.id,
        prompt=payload.prompt,
        style=payload.style,
        image_url=image_url,
    )
    db.add(record)
    db.commit()

    return {"image_url": image_url, "prompt": payload.prompt, "style": payload.style}


@router.get("/history")
def get_image_history(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    images = db.query(GeneratedImage).filter(
        GeneratedImage.user_id == current_user.id
    ).order_by(GeneratedImage.created_at.desc()).limit(50).all()
    return [{"id": i.id, "prompt": i.prompt, "style": i.style, "image_url": i.image_url, "created_at": i.created_at} for i in images]
