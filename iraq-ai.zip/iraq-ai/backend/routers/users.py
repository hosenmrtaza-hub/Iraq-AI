from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional

from core.database import get_db
from core.security import get_password_hash
from data_models.models import User, Conversation, GeneratedImage
from dependencies.auth import get_current_user

router = APIRouter()


class UserProfile(BaseModel):
    id: int
    name: str
    email: str
    plan: str
    created_at: str

    class Config:
        from_attributes = True


class UpdateProfileRequest(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = None


@router.get("/me", response_model=UserProfile)
def get_profile(current_user: User = Depends(get_current_user)):
    return {
        "id": current_user.id,
        "name": current_user.name,
        "email": current_user.email,
        "plan": current_user.plan,
        "created_at": str(current_user.created_at),
    }


@router.patch("/me")
def update_profile(
    payload: UpdateProfileRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if payload.name:
        current_user.name = payload.name
    if payload.email:
        current_user.email = payload.email
    if payload.password:
        current_user.hashed_pw = get_password_hash(payload.password)
    db.commit()
    db.refresh(current_user)
    return {"message": "تم تحديث الملف الشخصي بنجاح"}


@router.get("/me/stats")
def get_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    conv_count  = db.query(Conversation).filter(Conversation.user_id == current_user.id).count()
    image_count = db.query(GeneratedImage).filter(GeneratedImage.user_id == current_user.id).count()
    return {
        "conversations": conv_count,
        "images_generated": image_count,
        "plan": current_user.plan,
        "member_since": str(current_user.created_at.date()),
    }
