from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from routers import auth, chat, images, users
from core.database import engine, Base

# Create all tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="IRAQ AI API",
    description="Backend API for IRAQ AI - Arabic AI Chatbot",
    version="1.0.0",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(auth.router,   prefix="/auth",   tags=["Authentication"])
app.include_router(chat.router,   prefix="/chat",   tags=["Chat"])
app.include_router(images.router, prefix="/images", tags=["Images"])
app.include_router(users.router,  prefix="/users",  tags=["Users"])

# Serve built frontend in production
if os.path.exists("../frontend/dist"):
    app.mount("/", StaticFiles(directory="../frontend/dist", html=True), name="static")


@app.get("/health")
def health_check():
    return {"status": "ok", "service": "IRAQ AI API"}
