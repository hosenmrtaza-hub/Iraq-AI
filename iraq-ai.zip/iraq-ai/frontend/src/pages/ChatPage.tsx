import { useState, useRef, useEffect } from "react";
import Sidebar from "../components/Sidebar";
import MessageBubble from "../components/MessageBubble";
import ImageModal from "../components/ImageModal";
import ProfileModal from "../components/ProfileModal";
import TypingDots from "../components/TypingDots";
import { sendMessage as apiSendMessage, generateImage } from "../lib/api";

const SUGGESTIONS = [
  "اشرح لي مفهوم الذكاء الاصطناعي",
  "أنشئ قصيدة باللغة العربية",
  "ساعدني في كتابة كود Python",
];

const INIT_MESSAGES = [
  {
    id: 1, role: "assistant", time: "10:00 ص",
    content: "مرحباً! أنا IRAQ AI، مساعدك الذكي العربي. كيف يمكنني مساعدتك اليوم؟",
  },
];

export default function ChatPage() {
  const [messages, setMessages] = useState(INIT_MESSAGES);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showImage, setShowImage] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [listening, setListening] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const send = async () => {
    if (!input.trim()) return;
    const now = new Date().toLocaleTimeString("ar-IQ", { hour: "2-digit", minute: "2-digit" });
    const userMsg = { id: Date.now(), role: "user", content: input, time: now };
    setMessages((p) => [...p, userMsg]);
    setInput("");
    setTyping(true);
    try {
      const reply = await apiSendMessage(input);
      setMessages((p) => [...p, { id: Date.now() + 1, role: "assistant", content: reply, time: now }]);
    } catch {
      setMessages((p) => [...p, { id: Date.now() + 1, role: "assistant", content: "حدث خطأ. يرجى المحاولة مرة أخرى.", time: now }]);
    } finally {
      setTyping(false);
    }
  };

  const toggleListen = () => {
    setListening(true);
    const recognition = (window as any).webkitSpeechRecognition
      ? new (window as any).webkitSpeechRecognition()
      : null;
    if (recognition) {
      recognition.lang = "ar-IQ";
      recognition.onresult = (e: any) => {
        setInput(e.results[0][0].transcript);
        setListening(false);
      };
      recognition.onerror = () => setListening(false);
      recognition.start();
    } else {
      setTimeout(() => { setListening(false); }, 2000);
    }
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;600;700;800&display=swap');
        * { margin:0; padding:0; box-sizing:border-box; }
        html,body { height:100%; background:#f1f5f9; }
        ::-webkit-scrollbar { width:4px; }
        ::-webkit-scrollbar-thumb { background:#e2e8f0; border-radius:4px; }
        @keyframes riseIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        @keyframes fadeIn { from{opacity:0} to{opacity:1} }
        @keyframes ripple { 0%{box-shadow:0 0 0 0 rgba(99,102,241,.4)} 70%{box-shadow:0 0 0 12px rgba(99,102,241,0)} 100%{box-shadow:0 0 0 0 rgba(99,102,241,0)} }
        textarea::placeholder { color:#94a3b8; }
        button { transition:all .18s ease; }
        button:hover { opacity:.88; }
      `}</style>

      <div style={{ display:"flex", height:"100vh", width:"100vw", fontFamily:"'Tajawal', sans-serif", background:"#f1f5f9" }}>
        <Sidebar
          open={sidebarOpen}
          onNewChat={() => setMessages([])}
          onOpenProfile={() => setShowProfile(true)}
        />

        <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden", minWidth:0 }}>
          {/* Topbar */}
          <div style={{ height:60, display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0 20px", background:"#fff", borderBottom:"1px solid #f1f5f9", boxShadow:"0 1px 6px rgba(0,0,0,0.04)", flexShrink:0, zIndex:10 }}>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <button onClick={() => setShowImage(true)} style={{ display:"flex", alignItems:"center", gap:7, padding:"7px 14px", background:"#f5f3ff", border:"1px solid #e0e7ff", borderRadius:9, cursor:"pointer", color:"#6366f1", fontSize:13, fontWeight:600, fontFamily:"'Tajawal', sans-serif" }}>
                🖼️ توليد صور
              </button>
              <button onClick={() => setShowProfile(true)} style={{ width:34, height:34, background:"#f8fafc", border:"1px solid #f1f5f9", borderRadius:9, display:"flex", alignItems:"center", justifyContent:"center", color:"#64748b", cursor:"pointer" }}>⚙️</button>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ direction:"rtl", textAlign:"right" }}>
                <div style={{ fontWeight:800, color:"#0f172a", fontSize:15 }}>IRAQ AI</div>
                <div style={{ display:"flex", alignItems:"center", gap:5, justifyContent:"flex-end" }}>
                  <span style={{ color:"#94a3b8", fontSize:11 }}>deepseek-v3.2</span>
                  <div style={{ width:6, height:6, borderRadius:"50%", background:"#22c55e" }} />
                </div>
              </div>
              <button onClick={() => setSidebarOpen((v) => !v)} style={{ width:34, height:34, background:"#f8fafc", border:"1px solid #f1f5f9", borderRadius:9, display:"flex", alignItems:"center", justifyContent:"center", color:"#6366f1", cursor:"pointer" }}>☰</button>
            </div>
          </div>

          {/* Messages */}
          <div style={{ flex:1, overflowY:"auto", padding:"28px 32px", background:"#f8fafc" }}>
            {messages.length === 0 && (
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", height:"100%", animation:"riseIn .5s ease", direction:"rtl", textAlign:"center" }}>
                <div style={{ width:72, height:72, borderRadius:20, marginBottom:18, background:"linear-gradient(135deg,#6366f1,#8b5cf6)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:34, boxShadow:"0 10px 32px rgba(99,102,241,0.25)" }}>🌙</div>
                <h2 style={{ fontWeight:800, color:"#0f172a", fontSize:24, marginBottom:8 }}>مرحباً بك في IRAQ AI</h2>
                <p style={{ color:"#64748b", fontSize:15, maxWidth:340, lineHeight:1.7 }}>ابدأ محادثة جديدة أو اختر من المحادثات السابقة</p>
              </div>
            )}
            {messages.map((msg) => <MessageBubble key={msg.id} msg={msg} />)}
            {typing && (
              <div style={{ display:"flex", alignItems:"flex-end", gap:10, animation:"riseIn .3s ease" }}>
                <div style={{ width:34, height:34, borderRadius:10, background:"linear-gradient(135deg,#6366f1,#8b5cf6)", display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontWeight:800, fontSize:12 }}>AI</div>
                <div style={{ background:"#fff", borderRadius:"4px 18px 18px 18px", boxShadow:"0 2px 10px rgba(0,0,0,0.06)", border:"1px solid rgba(0,0,0,0.05)" }}>
                  <TypingDots />
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Input */}
          <div style={{ padding:"12px 24px 18px", background:"#fff", borderTop:"1px solid #f1f5f9", flexShrink:0 }}>
            <div style={{ display:"flex", gap:8, justifyContent:"flex-end", marginBottom:10, flexWrap:"wrap" }}>
              {SUGGESTIONS.map((s) => (
                <button key={s} onClick={() => { setInput(s); inputRef.current?.focus(); }} style={{ padding:"4px 12px", borderRadius:20, background:"#f8fafc", border:"1px solid #e2e8f0", color:"#64748b", fontSize:12, cursor:"pointer", fontFamily:"'Tajawal', sans-serif", direction:"rtl" }}>{s}</button>
              ))}
            </div>
            <div style={{ display:"flex", alignItems:"flex-end", gap:8, background:"#f8fafc", border:"1.5px solid #e2e8f0", borderRadius:14, padding:"6px 8px" }}>
              <button onClick={send} disabled={!input.trim()} style={{ width:38, height:38, borderRadius:10, flexShrink:0, background:input.trim()?"linear-gradient(135deg,#6366f1,#7c3aed)":"#e2e8f0", border:"none", cursor:input.trim()?"pointer":"not-allowed", display:"flex", alignItems:"center", justifyContent:"center", color:input.trim()?"#fff":"#94a3b8", boxShadow:input.trim()?"0 3px 12px rgba(99,102,241,0.3)":"none" }}>➤</button>
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                placeholder="اكتب رسالتك هنا... (Enter للإرسال)"
                rows={1}
                style={{ flex:1, background:"transparent", border:"none", outline:"none", color:"#1e293b", fontSize:14.5, fontFamily:"'Tajawal', sans-serif", direction:"rtl", resize:"none", padding:"9px 6px", lineHeight:1.6, maxHeight:130, overflowY:"auto" }}
              />
              <button onClick={toggleListen} style={{ width:38, height:38, borderRadius:10, flexShrink:0, background:listening?"#fef2f2":"#f1f5f9", border:listening?"1.5px solid #fca5a5":"1.5px solid #e2e8f0", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", color:listening?"#ef4444":"#64748b", animation:listening?"ripple 1.2s ease infinite":"none" }}>🎤</button>
            </div>
            <div style={{ textAlign:"center", marginTop:9, color:"#cbd5e1", fontSize:11 }}>IRAQ AI · deepseek-v3.2 · مدعوم بالذكاء الاصطناعي</div>
          </div>
        </div>

        {showImage   && <ImageModal   onClose={() => setShowImage(false)}   onGenerate={generateImage} />}
        {showProfile && <ProfileModal onClose={() => setShowProfile(false)} />}
      </div>
    </>
  );
}
