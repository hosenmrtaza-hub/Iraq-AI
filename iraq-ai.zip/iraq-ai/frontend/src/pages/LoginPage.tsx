import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login } from "../lib/api";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await login(email, password);
      navigate("/chat");
    } catch {
      setError("بيانات الدخول غير صحيحة. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center", background:"#f8fafc", fontFamily:"'Tajawal', sans-serif", direction:"rtl" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;600;700;800&display=swap');`}</style>
      <div style={{ width:400, background:"#fff", borderRadius:20, padding:36, boxShadow:"0 10px 40px rgba(0,0,0,0.08)", border:"1px solid #f1f5f9" }}>
        <div style={{ textAlign:"center", marginBottom:28 }}>
          <div style={{ width:60, height:60, borderRadius:16, background:"linear-gradient(135deg,#6366f1,#8b5cf6)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:28, margin:"0 auto 14px", boxShadow:"0 6px 20px rgba(99,102,241,0.3)" }}>🌙</div>
          <h1 style={{ fontWeight:800, color:"#0f172a", fontSize:22, margin:0 }}>تسجيل الدخول</h1>
          <p style={{ color:"#94a3b8", fontSize:14, marginTop:6 }}>مرحباً بك في IRAQ AI</p>
        </div>
        <form onSubmit={handleLogin}>
          <div style={{ marginBottom:16 }}>
            <label style={{ display:"block", color:"#475569", fontSize:13, fontWeight:600, marginBottom:6 }}>البريد الإلكتروني</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
              placeholder="example@email.com"
              style={{ width:"100%", padding:"11px 14px", border:"1.5px solid #e2e8f0", borderRadius:10, fontSize:14, outline:"none", fontFamily:"inherit", color:"#1e293b", direction:"ltr", boxSizing:"border-box" }} />
          </div>
          <div style={{ marginBottom:20 }}>
            <label style={{ display:"block", color:"#475569", fontSize:13, fontWeight:600, marginBottom:6 }}>كلمة المرور</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required
              placeholder="••••••••"
              style={{ width:"100%", padding:"11px 14px", border:"1.5px solid #e2e8f0", borderRadius:10, fontSize:14, outline:"none", fontFamily:"inherit", color:"#1e293b", direction:"ltr", boxSizing:"border-box" }} />
          </div>
          {error && <div style={{ background:"#fef2f2", border:"1px solid #fecaca", borderRadius:8, padding:"10px 14px", color:"#dc2626", fontSize:13, marginBottom:16 }}>{error}</div>}
          <button type="submit" disabled={loading} style={{ width:"100%", padding:"13px", background:"linear-gradient(135deg,#6366f1,#7c3aed)", border:"none", borderRadius:12, color:"#fff", fontSize:15, fontWeight:700, cursor:loading?"not-allowed":"pointer", fontFamily:"inherit", boxShadow:"0 4px 16px rgba(99,102,241,0.3)" }}>
            {loading ? "جارٍ الدخول..." : "تسجيل الدخول"}
          </button>
        </form>
      </div>
    </div>
  );
}
