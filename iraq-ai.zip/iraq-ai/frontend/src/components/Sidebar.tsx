const HISTORY = [
  { id: 1, title: "ما هو الذكاء الاصطناعي؟", date: "اليوم",         preview: "الذكاء الاصطناعي هو محاكاة..." },
  { id: 2, title: "أنشئ صورة لمدينة بغداد",   date: "اليوم",         preview: "تم إنشاء الصورة بنجاح" },
  { id: 3, title: "كيف أتعلم البرمجة؟",       date: "أمس",           preview: "للبدء في البرمجة عليك..." },
  { id: 4, title: "ترجمة نص إلى الإنجليزية", date: "أمس",           preview: "Here is the translation..." },
  { id: 5, title: "وصفة مضغوف عراقي",         date: "الأسبوع الماضي", preview: "المكونات: رز، لحم..." },
  { id: 6, title: "تاريخ بلاد الرافدين",      date: "الأسبوع الماضي", preview: "بلاد الرافدين هي..." },
];

interface SidebarProps {
  open: boolean;
  onNewChat: () => void;
  onOpenProfile: () => void;
}

export default function Sidebar({ open, onNewChat, onOpenProfile }: SidebarProps) {
  const groups = [...new Set(HISTORY.map((h) => h.date))];

  return (
    <div style={{
      width: open ? 272 : 0,
      flexShrink: 0,
      background: "#fff",
      borderLeft: "1px solid #f1f5f9",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      transition: "width .32s cubic-bezier(.16,1,.3,1)",
      boxShadow: open ? "4px 0 24px rgba(0,0,0,0.04)" : "none",
    }}>
      <div style={{ width: 272, height: "100%", display: "flex", flexDirection: "column" }}>

        {/* Brand */}
        <div style={{ padding: "22px 18px 16px", borderBottom: "1px solid #f8fafc" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, justifyContent: "flex-end", marginBottom: 14 }}>
            <div style={{ direction: "rtl" }}>
              <div style={{ fontWeight: 800, color: "#0f172a", fontSize: 19, letterSpacing: -0.5 }}>IRAQ AI</div>
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 1 }}>مساعدك الذكي العربي</div>
            </div>
            <div style={{ width: 40, height: 40, borderRadius: 12, background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 20, boxShadow: "0 4px 14px rgba(99,102,241,0.25)" }}>🌙</div>
          </div>
          <button onClick={onNewChat} style={{ width: "100%", padding: "9px 14px", background: "#f8fafc", border: "1.5px dashed #e2e8f0", borderRadius: 10, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 8, color: "#6366f1", fontFamily: "'Tajawal', sans-serif", fontSize: 13, fontWeight: 600 }}>
            <span>محادثة جديدة</span>
            <span>＋</span>
          </button>
        </div>

        {/* History */}
        <div style={{ flex: 1, overflowY: "auto", padding: "12px 10px" }}>
          {groups.map((group) => (
            <div key={group} style={{ marginBottom: 8 }}>
              <div style={{ fontSize: 11, color: "#94a3b8", fontWeight: 600, textAlign: "right", padding: "6px 8px 4px" }}>{group}</div>
              {HISTORY.filter((h) => h.date === group).map((item) => (
                <button key={item.id} style={{ width: "100%", padding: "9px 10px", borderRadius: 9, border: "none", cursor: "pointer", textAlign: "right", marginBottom: 2, background: "transparent", display: "flex", flexDirection: "column", gap: 2 }}>
                  <div style={{ color: "#334155", fontSize: 13, fontFamily: "'Tajawal', sans-serif", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", width: "100%" }}>{item.title}</div>
                  <div style={{ color: "#94a3b8", fontSize: 11, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", width: "100%" }}>{item.preview}</div>
                </button>
              ))}
            </div>
          ))}
        </div>

        {/* User footer */}
        <div style={{ padding: "12px 12px 18px", borderTop: "1px solid #f8fafc" }}>
          <button onClick={onOpenProfile} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, background: "#f8fafc", border: "1px solid #f1f5f9", borderRadius: 12, padding: "10px 12px", cursor: "pointer", justifyContent: "flex-end" }}>
            <div style={{ direction: "rtl", flex: 1, textAlign: "right" }}>
              <div style={{ color: "#1e293b", fontSize: 13, fontWeight: 600, fontFamily: "'Tajawal', sans-serif" }}>أحمد محمد</div>
              <div style={{ color: "#94a3b8", fontSize: 11 }}>الخطة المجانية · 47 رسالة</div>
            </div>
            <div style={{ width: 34, height: 34, borderRadius: "50%", background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 13, boxShadow: "0 2px 8px rgba(99,102,241,0.2)" }}>أ</div>
          </button>
        </div>
      </div>
    </div>
  );
}
