interface Message {
  id: number;
  role: string;
  content: string;
  time: string;
}

export default function MessageBubble({ msg }: { msg: Message }) {
  const isUser = msg.role === "user";
  const lines = msg.content.split("\n");

  return (
    <div style={{ display: "flex", flexDirection: isUser ? "row-reverse" : "row", alignItems: "flex-end", gap: 10, marginBottom: 22, animation: "riseIn .35s ease both" }}>
      {!isUser && (
        <div style={{ width: 34, height: 34, borderRadius: 10, flexShrink: 0, background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 12, boxShadow: "0 4px 12px rgba(99,102,241,0.25)" }}>AI</div>
      )}
      <div style={{
        maxWidth: "64%",
        background: isUser ? "linear-gradient(135deg,#6366f1 0%,#7c3aed 100%)" : "#fff",
        borderRadius: isUser ? "18px 4px 18px 18px" : "4px 18px 18px 18px",
        padding: "12px 16px",
        color: isUser ? "#fff" : "#1e293b",
        fontSize: 14.5,
        lineHeight: 1.75,
        direction: "rtl",
        textAlign: "right",
        boxShadow: isUser ? "0 4px 18px rgba(99,102,241,0.25)" : "0 2px 12px rgba(0,0,0,0.06)",
        border: isUser ? "none" : "1px solid rgba(0,0,0,0.05)",
        fontFamily: "'Tajawal', sans-serif",
      }}>
        {lines.map((line, i) => {
          if (!line) return <div key={i} style={{ height: 6 }} />;
          const boldMatch = line.match(/^\*\*(.+?)\*\* — (.+)$/);
          if (boldMatch) return (
            <div key={i} style={{ marginBottom: 8 }}>
              <span style={{ fontWeight: 700, color: isUser ? "#e0e7ff" : "#4f46e5" }}>{boldMatch[1]}</span>
              <span style={{ color: isUser ? "rgba(255,255,255,0.85)" : "#475569" }}> — {boldMatch[2]}</span>
            </div>
          );
          return <p key={i} style={{ margin: 0, marginBottom: 2 }}>{line}</p>;
        })}
        <div style={{ fontSize: 11, marginTop: 6, color: isUser ? "rgba(255,255,255,0.5)" : "#94a3b8", textAlign: isUser ? "left" : "right" }}>{msg.time}</div>
      </div>
    </div>
  );
}
