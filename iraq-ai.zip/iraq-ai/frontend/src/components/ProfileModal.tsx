interface ProfileModalProps {
  onClose: () => void;
}

export default function ProfileModal({ onClose }: ProfileModalProps) {
  const stats = [
    { icon: "💬", label: "الرسائل المتبقية", value: "47 / 50" },
    { icon: "🖼️", label: "الصور المُنشأة",   value: "12" },
    { icon: "📅", label: "تاريخ الانضمام",   value: "يناير 2025" },
  ];

  return (
    <div
      onClick={(e) => e.target === e.currentTarget && onClose()}
      style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.45)", backdropFilter: "blur(6px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 200, animation: "fadeIn .25s ease" }}
    >
      <style>{`
        @keyframes fadeIn { from{opacity:0} to{opacity:1} }
        @keyframes riseIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        @keyframes growBar { from{width:0} }
      `}</style>
      <div style={{ width: 400, background: "#fff", borderRadius: 22, boxShadow: "0 30px 80px rgba(0,0,0,0.18)", overflow: "hidden", animation: "riseIn .35s cubic-bezier(.16,1,.3,1)" }}>
        <div style={{ height: 6, background: "linear-gradient(90deg,#6366f1,#8b5cf6,#ec4899)" }} />
        <div style={{ padding: "28px 24px" }}>
          {/* Header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
            <button onClick={onClose} style={{ width: 32, height: 32, borderRadius: 8, border: "1px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 16, color: "#64748b" }}>✕</button>
            <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 17, fontFamily: "'Tajawal', sans-serif" }}>الملف الشخصي</div>
          </div>

          {/* Avatar */}
          <div style={{ textAlign: "center", marginBottom: 24 }}>
            <div style={{ width: 72, height: 72, borderRadius: "50%", margin: "0 auto 12px", background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 28, fontWeight: 800, boxShadow: "0 8px 24px rgba(99,102,241,0.3)" }}>أ</div>
            <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 17, fontFamily: "'Tajawal', sans-serif" }}>أحمد محمد</div>
            <div style={{ color: "#94a3b8", fontSize: 13, marginTop: 2 }}>ahmed@example.com</div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 5, marginTop: 8, background: "#fef9c3", borderRadius: 20, padding: "3px 12px", color: "#854d0e", fontSize: 12, fontWeight: 600, fontFamily: "'Tajawal', sans-serif" }}>
              ⭐ الخطة المجانية
            </div>
          </div>

          {/* Stats */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 20 }}>
            {stats.map((s, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 14px", background: "#f8fafc", borderRadius: 10, direction: "rtl", border: "1px solid #f1f5f9" }}>
                <span style={{ color: "#475569", fontSize: 13, fontFamily: "'Tajawal', sans-serif", display: "flex", alignItems: "center", gap: 7 }}><span>{s.icon}</span>{s.label}</span>
                <span style={{ color: "#6366f1", fontWeight: 700, fontSize: 13 }}>{s.value}</span>
              </div>
            ))}
          </div>

          {/* Usage bar */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, direction: "rtl" }}>
              <span style={{ fontSize: 12, color: "#94a3b8", fontFamily: "'Tajawal', sans-serif" }}>الاستخدام الشهري</span>
              <span style={{ fontSize: 12, color: "#6366f1", fontWeight: 600 }}>94%</span>
            </div>
            <div style={{ height: 6, background: "#f1f5f9", borderRadius: 10, overflow: "hidden" }}>
              <div style={{ height: "100%", width: "94%", borderRadius: 10, background: "linear-gradient(90deg,#6366f1,#8b5cf6)", animation: "growBar .8s ease both" }} />
            </div>
          </div>

          <button style={{ width: "100%", padding: "13px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#6366f1,#7c3aed)", color: "#fff", fontFamily: "'Tajawal', sans-serif", fontSize: 15, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 18px rgba(99,102,241,0.3)" }}>
            ⬆️ ترقية إلى الخطة الاحترافية
          </button>
        </div>
      </div>
    </div>
  );
}
