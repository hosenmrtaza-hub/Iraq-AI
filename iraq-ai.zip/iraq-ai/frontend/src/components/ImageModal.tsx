import { useState } from "react";

interface ImageModalProps {
  onClose: () => void;
  onGenerate: (prompt: string, style: string) => Promise<string>;
}

const STYLES = ["فوتوغرافي", "فن رقمي", "رسم زيتي", "رسوم متحركة"];

export default function ImageModal({ onClose, onGenerate }: ImageModalProps) {
  const [prompt, setPrompt]   = useState("");
  const [style, setStyle]     = useState("فوتوغرافي");
  const [stage, setStage]     = useState<"idle" | "loading" | "done">("idle");
  const [imageUrl, setImageUrl] = useState("");

  const generate = async () => {
    if (!prompt.trim()) return;
    setStage("loading");
    try {
      const url = await onGenerate(prompt, style);
      setImageUrl(url);
      setStage("done");
    } catch {
      setStage("idle");
    }
  };

  return (
    <div
      onClick={(e) => e.target === e.currentTarget && onClose()}
      style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.45)", backdropFilter: "blur(6px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 200, animation: "fadeIn .25s ease" }}
    >
      <style>{`
        @keyframes spinIt { to { transform: rotate(360deg); } }
        @keyframes fadeIn { from{opacity:0} to{opacity:1} }
        @keyframes riseIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
      `}</style>
      <div style={{ width: 540, background: "#fff", borderRadius: 22, boxShadow: "0 30px 80px rgba(0,0,0,0.18)", overflow: "hidden", animation: "riseIn .35s cubic-bezier(.16,1,.3,1)" }}>
        {/* Header */}
        <div style={{ padding: "20px 24px", borderBottom: "1px solid #f1f5f9", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button onClick={onClose} style={{ width: 32, height: 32, borderRadius: 8, border: "1px solid #e2e8f0", background: "#fff", cursor: "pointer", fontSize: 16, color: "#64748b" }}>✕</button>
          <div style={{ display: "flex", alignItems: "center", gap: 10, direction: "rtl" }}>
            <div>
              <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 16, fontFamily: "'Tajawal', sans-serif" }}>توليد الصور</div>
              <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 1 }}>Gemini 2.5 Flash Image</div>
            </div>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: "linear-gradient(135deg,#6366f1,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 18 }}>🖼️</div>
          </div>
        </div>

        {/* Canvas */}
        <div style={{ padding: "20px 24px 0" }}>
          <div style={{ width: "100%", height: 220, borderRadius: 14, background: stage === "done" ? "linear-gradient(135deg,#e0e7ff,#ede9fe,#fce7f3)" : "#f8fafc", border: "1.5px dashed #e2e8f0", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", position: "relative", marginBottom: 18 }}>
            {stage === "idle" && <div style={{ textAlign: "center", color: "#94a3b8" }}><div style={{ fontSize: 36, marginBottom: 8 }}>🖼️</div><div style={{ fontSize: 13, fontFamily: "'Tajawal', sans-serif" }}>ستظهر الصورة المُنشأة هنا</div></div>}
            {stage === "loading" && <div style={{ textAlign: "center" }}><div style={{ width: 44, height: 44, margin: "0 auto 14px", border: "3px solid #e0e7ff", borderTopColor: "#6366f1", borderRadius: "50%", animation: "spinIt 0.9s linear infinite" }} /><div style={{ color: "#6366f1", fontSize: 13, fontFamily: "'Tajawal', sans-serif", fontWeight: 600 }}>جارٍ الإنشاء...</div></div>}
            {stage === "done" && (
              imageUrl
                ? <img src={imageUrl} alt="generated" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                : <div style={{ textAlign: "center", flexDirection: "column", display: "flex", alignItems: "center", gap: 8 }}><div style={{ fontSize: 42 }}>🌙✨</div><div style={{ fontFamily: "'Tajawal', sans-serif", fontSize: 14, color: "#4f46e5", fontWeight: 600, direction: "rtl", textAlign: "center" }}>{prompt}</div></div>
            )}
          </div>

          {/* Style pills */}
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginBottom: 14, flexWrap: "wrap" }}>
            {STYLES.map((s) => (
              <button key={s} onClick={() => setStyle(s)} style={{ padding: "5px 14px", borderRadius: 20, cursor: "pointer", background: style === s ? "#6366f1" : "#f1f5f9", color: style === s ? "#fff" : "#64748b", border: "none", fontSize: 12, fontFamily: "'Tajawal', sans-serif", fontWeight: style === s ? 600 : 400, transition: "all .2s" }}>{s}</button>
            ))}
          </div>

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="صف ما تريد رؤيته... مثال: منظر بغداد ليلاً مع نهر دجلة"
            style={{ width: "100%", minHeight: 80, background: "#f8fafc", border: "1.5px solid #e2e8f0", borderRadius: 12, padding: "12px 14px", color: "#1e293b", fontSize: 14, fontFamily: "'Tajawal', sans-serif", direction: "rtl", resize: "none", outline: "none", boxSizing: "border-box", lineHeight: 1.6 }}
          />
        </div>

        <div style={{ padding: "14px 24px 22px", display: "flex", gap: 10 }}>
          <button onClick={onClose} style={{ flex: 1, padding: "12px", borderRadius: 12, background: "#f1f5f9", border: "none", cursor: "pointer", color: "#64748b", fontFamily: "'Tajawal', sans-serif", fontSize: 14, fontWeight: 600 }}>إغلاق</button>
          <button onClick={generate} disabled={!prompt.trim() || stage === "loading"} style={{ flex: 2, padding: "12px", borderRadius: 12, border: "none", background: prompt.trim() && stage !== "loading" ? "linear-gradient(135deg,#6366f1,#7c3aed)" : "#e2e8f0", color: prompt.trim() && stage !== "loading" ? "#fff" : "#94a3b8", cursor: prompt.trim() && stage !== "loading" ? "pointer" : "not-allowed", fontFamily: "'Tajawal', sans-serif", fontSize: 14, fontWeight: 700, boxShadow: prompt.trim() && stage !== "loading" ? "0 4px 14px rgba(99,102,241,0.3)" : "none", transition: "all .25s" }}>
            {stage === "loading" ? "جارٍ الإنشاء..." : "✨ أنشئ الصورة"}
          </button>
        </div>
      </div>
    </div>
  );
}
