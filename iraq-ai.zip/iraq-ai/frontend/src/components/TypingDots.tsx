export default function TypingDots() {
  return (
    <>
      <style>{`
        @keyframes dotBounce {
          0%, 60%, 100% { transform: translateY(0); }
          30% { transform: translateY(-6px); }
        }
      `}</style>
      <div style={{ display: "flex", gap: 5, padding: "14px 18px", alignItems: "center" }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: "#94a3b8", animation: `dotBounce 1.4s ease-in-out ${i * 0.2}s infinite` }} />
        ))}
      </div>
    </>
  );
}
